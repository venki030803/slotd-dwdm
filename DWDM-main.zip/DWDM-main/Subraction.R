num1=as.integer(readline(prompt = "Enter the num 1:"))
num2 =as.integer(readline(prompt = "Enter a number2:"))
sub=num1-num2
print((paste("subraction value:",sub)))
