x <- rnorm(100, mean = 0, sd = 1)
hist(x)
dnorm(1, mean = 0, sd = 1)
pnorm(1, mean = 0, sd = 1)