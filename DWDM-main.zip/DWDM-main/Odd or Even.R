num =as.integer(readline(prompt = "Enter a number:"))
if (num %% 2 ==0){
  print(paste(num,"is Even number!!"))
}else{
  print(paste(num,"is Odd number!!"))
}
